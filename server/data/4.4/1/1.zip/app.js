const store = require('./store');
const { addTaskToQueue, removeTaskFromQueue } = require('./taskQueueSlice');

// Тестовая задача
const sampleTask = {
  id: Date.now(),
  title: 'Образец задачи',
  description: 'Это тестовая задача.',
};

console.log('Исходное состояние:', store.getState());

// Добавляем задачу в очередь
store.dispatch(addTaskToQueue(sampleTask));
console.log('После добавления задачи:', store.getState());

// Проверяем наличие задачи в очереди
const firstTask = store.getState().tasks.queue[0];
if (firstTask) console.log('Первая задача в очереди:', firstTask);
else console.log('Очередь пуста.');

// Убираем задачу из очереди
store.dispatch(removeTaskFromQueue(firstTask.id));
console.log('После удаления задачи:', store.getState());

// Повторная проверка очереди
const secondCheck = store.getState().tasks.queue[0];
if (!secondCheck) console.log('Очередь пуста сейчас.');