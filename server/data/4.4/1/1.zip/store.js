const { configureStore } = require('@reduxjs/toolkit');
const taskQueueSlice = require('./taskQueueSlice');

const store = configureStore({
  reducer: {
    tasks: taskQueueSlice.reducer,
  },
});

module.exports = store;