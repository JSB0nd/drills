const { createSlice } = require('@reduxjs/toolkit');

// Исходное состояние очереди
const initialState = {
  queue: [],
};

// Создаём слайс с действиями и редюсерами
const taskQueueSlice = createSlice({
  name: 'tasks',
  initialState,
  reducers: {
    addTaskToQueue(state, action) {
      state.queue.push(action.payload); // добавляем задачу в конец очереди
    },
    removeTaskFromQueue(state, action) {
      const index = state.queue.findIndex((task) => task.id === action.payload);
      if (index !== -1) {
        state.queue.splice(index, 1); // удаляем задачу по её id
      }
    },
  },
});

// Экспортируем генераторы действий
module.exports.addTaskToQueue = taskQueueSlice.actions.addTaskToQueue;
module.exports.removeTaskFromQueue = taskQueueSlice.actions.removeTaskFromQueue;

// Экспорт самого редюсера
module.exports = {
    reducer: taskQueueSlice.reducer,
    addTaskToQueue: taskQueueSlice.actions.addTaskToQueue,
    removeTaskFromQueue: taskQueueSlice.actions.removeTaskFromQueue,
};